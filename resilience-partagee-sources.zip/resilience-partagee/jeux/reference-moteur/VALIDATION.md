# Contrôles exécutés — 13 octobre 2026

## Moteur

Commande : `node tests/engine_tests.js`

- **200 simulations complètes**, soit 3 000 états quinquennaux.
- Les 72 combinaisons des 2 périmètres, 6 terrains et 6 stratégies.
- 128 configurations supplémentaires avec politiques, coefficients et structures variés.
- **63 442 assertions** : valeurs finies, ressources non croissantes, stocks non négatifs,
  bilans des biens, de la dette et du carbone, reproduction des décisions JSON, absence de
  bonus associé au nom de la stratégie, effets de l’épuisement et tests d’ablation.
- Référence initiale DICE calculée indépendamment ; atelier avant contrôlé pour valeurs finies
  et ordre attendu de deux politiques de décarbonation sous les mêmes paramètres.
- 120 configurations de sensibilité appariées, contrôle de l’ordre des percentiles.

Résidus absolus maximaux sur les identités, dans ces essais :

| Identité | Résidu maximal |
|---|---:|
| Carbone | 1,11 × 10^-12 |
| Biens et services | 4,55 × 10^-13 |
| Évolution de dette | 9,10 × 10^-13 |
| Stock matériel | 7,11 × 10^-15 |

Les identités de dette sont aussi confrontées aux flux budgétaires exposés. Un test numérique
vérifie le code implémenté ; il n’est pas une confirmation indépendante de la bonne théorie.
Le code complet et `tests/validation.json` sont fournis pour inspection et reproduction.

## Interface et intégration

Tests avec Chromium et Playwright, sur le HTML local chargé dans le navigateur :

- Dossier existant conservé ; ouverture et fermeture du laboratoire intégré.
- Trois décisions appliquées, réouverture sans perte d’état.
- Export effectif de sauvegarde JSON, CSV et bilan HTML ; import de la sauvegarde.
- Invalidation des résultats de sensibilité lorsqu’une décision change.
- Tutoriel en quatre étapes ; modification des repères de mission.
- Navigation des cinq rubriques à 320, 390, 768, 1100 et 1440 pixels de largeur.
- Aucune erreur JavaScript non interceptée pendant ces essais.
- Pas de débordement horizontal de la page ; les grandes tables ont leur propre défilement.
- Autres essais : quinze tours jusqu’en 2100, annulation, comparaison, sensibilité et
  contrôles accessibles dans l’interface.

Les navigateurs Safari et Firefox, la navigation sur un vrai appareil iOS/Android et la
publication réelle Here.now n’ont pas été testés ici. Les restrictions de navigateur sur
les fichiers locaux peuvent limiter le stockage ou le presse-papiers ; le code offre l’export.

## Publication Mac

Le lanceur fourni réutilise le protocole du précédent lanceur, avec le nouveau site intégré.
Sa syntaxe Bash, le SHA-256 de sa charge utile, le nombre d’octets et son manifeste sont contrôlés.
Il n’a pas été exécuté sur un compte réel pour cette version. Il ne modifie pas une publication
existante et ne commande aucun achat. Une erreur réseau ne signifie pas qu’un site a été publié.

## Ce qui n’est PAS validé

Aucun résultat du jeu n’a été validé par une estimation sur la France, par une expérience
causale ou par comparaison indépendante des trajectoires DICE/World3 originales. Les tests
ne démontrent ni la supériorité du résiliennisme, ni une prévision de 2100, ni l’exhaustivité des
risques. Les scénarios restent conditionnels aux structures et coefficients choisis.
