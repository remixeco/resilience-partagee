# Modèle et provenance — Horizons communs 1.0.0

## 1. Statut et périmètre

Ce jeu est un modèle hybride original et réduit. Il explore des interactions, sans estimation
statistique des coefficients sociaux/fiscaux. Il ne reproduit intégralement ni DICE-2023,
ni World3. Il n’existe pas de calibration nationale ou mondiale des sorties du jeu principal.
Une correspondance formelle avec des équations publiées n’est pas une validation des ajouts.

Le pas est de 5 ans. À chaque tour, les flux annuels représentatifs sont calculés à partir de
l’état de départ. Les investissements et stocks évoluent ; la nouvelle température dépend du
nouveau carbone. L’étiquette finale du tour réunit ces flux et stocks : elle ne remplace pas
cinq observations annuelles. Les intérêts sont capitalisés exactement pour les cinq paiements
annuels supposés constants. Les autres équations utilisent les discrétisations indiquées.

## 2. États

K : capital privé (250 au départ) ; Kpub : capital public (90) ; A : productivité (1) ;
H : compétences (1) ; S : services (1) ; R : adaptation (0,2) ; V : diversification (0,25) ;
G : exécution/coordination (0,6) ; μ : réduction effective des émissions (0,12) ;
I_m : intensité matérielle (1) ; sol : fertilité (1) ; agriculture : capacité alimentaire (1) ;
N : ressources non renouvelables (100, variable selon le terrain) ; P : pollution hors CO₂ (1) ;
L : population normalisée (1) ; D : engagements publics nets (100 ou 140 selon le terrain).
Carbone (GtC) : [910, 480, 1750] ; T atmosphère : 1,25 °C ; T océan : 0,18 °C.

TOUTES ces conditions du jeu principal sont scénarisées. Elles ne constituent pas des mesures
au 1er janvier 2025. Les variables démographiques, budgétaires et matérielles ne sont pas en euros
ou en nombre d’habitants. La consommation est ramenée à une référence commune de 55 unités par
personne normalisée, identique pour toutes les stratégies.

## 3. Production et usages

Production potentielle :

```
Q = 100 × A × (K/250)^0,30 × (Kpub/90)^0,08 × H^0,18 × L^0,70
```

Elle est corrigée par le manque de matières, l’alimentation, un petit ajustement de demande,
les chocs, les dommages climatiques et le coût réel de décarbonation.
Les exposants H/Kpub et la correction de demande sont des ajouts de jeu.

L’usure annuelle est de 4,5 % pour K et 3,5 % pour Kpub. L’investissement privé dépend du
prélèvement effectif selon une sensibilité éditable. Il n’y a pas de croissance gratuite
attribuée au nom d’une stratégie. Les transferts ne créent pas une seconde production.

```
Y = consommation réelle + investissement privé + usages publics réels
```

Le coût de décarbonation a déjà été déduit de Y. Il n’est ni une taxe ni une recette à recycler.
Les services, investissements, recherche, coordination, sols, réserves, logistique et moyens
d’urgence mobilisent Y. Les transferts et intérêts restent dans les comptes financiers.

## 4. Budget et engagements

```
Recettes = Y × [taxe + progressivité × (1 − réaction fiscale)] / 100
Dépenses primaires = usages publics réels + transferts
Solde initial annuel = recettes − dépenses primaires − r D
D_next = D × (1+r)^5 + (dépenses primaires − recettes) × [(1+r)^5 − 1]/r
```

r commence au taux du terrain, plus une prime de dette et d’éventuels chocs ; plafond 18 %.
Lorsque D est négatif, il représente des actifs financiers nets rémunérés au taux fictif de 1,2 %.
Le modèle ne décrit pas les contreparties de tous les actifs/passifs privés. Il n’est donc pas
un modèle financier intégral stock-flux cohérent. Ni défaut, ni rollover détaillé, banques,
inflation, change ou réaction BCE ne sont représentés. Des actifs ou dettes extrêmes déclenchent
un avertissement ; ce résultat ne prouve pas qu’un État réel pourrait financer ces positions.

Les pourcentages indiqués ne sont pas des taux de prélèvements français effectifs.
Les recettes réagissent à la production ; elles ne sont pas un montant exogène garanti.

## 5. Climat : formes DICE-2016

Carbone, pas quinquennal, E en GtCO₂/an et M en GtC :

```
b12 = 0,12 ; b23 = 0,007
b21 = b12 × 588/360 ; b32 = b23 × 360/1720
M_atm' = (1−b12) M_atm + b21 M_sup + 5 E/3,667
M_sup' = b12 M_atm + (1−b21−b23) M_sup + b32 M_prof
M_prof' = b23 M_sup + (1−b32) M_prof
F = 3,6813 log₂(M_atm'/588) + forçage exogène
T_atm' = T_atm + 0,1005 [F − (3,6813/ECS) T_atm − 0,088(T_atm−T_océan)]
T_océan' = T_océan + 0,025 (T_atm−T_océan)
```

La matrice conserve la masse : somme M_next = somme M + 5 E/3,667.
Les autres gaz sont réduits à un forçage exogène, pas convertis en masse de carbone.
Dommage de base : a T² / (1+a T²), a=0,00236. Variante convexe : ajout de
0,0015 × max(0,T−2)^4 avant transformation. Les réserves peuvent réduire une part du dommage
par une hypothèse propre au jeu ; elles ne refroidissent pas la planète.
Coût de décarbonation : θ(t) μ^2,6. Dans le jeu principal, θ(t)=0,075 × coût × exp(−0,006 t).
Ces coefficients de coûts et la dynamique de déploiement du jeu ne sont pas DICE-2023.

DICE-2023 modifie notamment les modules carbone/climat et le traitement des risques.
Notre choix transparent de la forme 2016 privilégie l’inspectabilité, pas la plus récente
estimation scientifique. Au-delà d’environ 4 °C, une fonction réduite de dommages est
particulièrement fragile : le jeu le signale.

Mode France : 1 % conventionnel du flux industriel piloté, 99 % déterminé par l’effort extérieur.
C’est un exemple de petite économie dans un système mondial, PAS une estimation des émissions
françaises ou une analyse des émissions importées. Les ressources de la région sont abstraites ;
il n’y a pas de commerce matériel bilatéral comptabilisé avec le reste du monde.

## 6. Boucles matérielles : inspiration World3, réduction explicite

```
Extraction souhaitée sur 5 ans = 5 × 0,82 × pression × Y/100 × intensité × (1−0,20 μ)
Extraction réalisable ≤ 0,95 × N
Y est plafonnée par cette matière disponible avant le calcul des autres usages.
N_next = N − extraction réalisable
Intensité_next = max(0,06, intensité × exp[−5(0,003+0,0045 circularité × efficacité × rendement)])
P_next = max(0, P + 5[0,065 Y/100 × intensité × (1−0,2μ) − 0,055 P/(1+0,05P)])
Sol_next = bornes[sol + 5(0,012(1−sol)+0,00065 circularité × efficacité−0,0018P−0,0015 max(0,T−1,25)^2)]
```

La limite de 95 % mobilisable par tour est une hypothèse de notre modèle réduit et évite une
singularité en un seul pas. À stock nul, la production de ce bloc est nulle. Le ratio financier
utilise un dénominateur minimal de 10^-9 dans ce cas ; il n’a alors pas de signification empirique.

La capacité agricole augmente avec le progrès technique/recherche. L’indice alimentaire est
proportionnel à agriculture × fertilité / population, puis soumis aux épisodes de récolte.
L’alimentation ne donne pas la distribution entre individus. La production alimentaire n’est
pas un secteur physique complet avec comptabilité intrants–extrants indépendante.
La population a une croissance nette stylisée qui diminue avec la pénurie alimentaire.

World3 original possède davantage d’états, de délais, de tables et des cohortes démographiques.
Il n’est pas possible d’appeler notre scénario « BAU de World3 » ni de comparer directement ses
indices avec les courbes originales. Voir le code PyWorld3 pour une implémentation différente,
documentée, du modèle technique de 1974.

## 7. Délais, services et répartition

Les cibles de compétence/service/coordination sont approchées par :

```
x_next = x + [1−exp(−5/τ)] × (cible−x)
```

Délais de base : H 18 ans ; S 15 ans ; G 12 ans ; décarbonation 12 ans ; diversification 8 ans.
Le multiplicateur de délais est éditable. Le rendement de la recherche/investissement et
l’efficacité de l’évaluation peuvent être abaissés à zéro. La réserve s’use de 4 % par an.
Un poste supplémentaire d’évaluation reste une dépense même si son efficacité est nulle.

L’écart de revenus est un ratio synthétique hauts/bas revenus, fonction des transferts et de
la progressivité, avec délai de huit ans. Ce n’est pas un Gini ni une distribution estimée.
L’accès aux besoins est une moyenne harmonique de biens accessibles, services et alimentation,
chaque composante bornée. La pondération/agrégation est normative et pédagogique, pas officielle.

## 8. Incertitude et comparaison

Les événements utilisent une fonction déterministe de la graine et du tour. Toutes les
stratégies comparées partagent événements, paramètres et départ. Les réponses d’urgence
jouées sont conservées pour le parcours du joueur. Les six références suivent leurs propres
politiques constantes, sans intervention d’urgence discrétionnaire.

L’ensemble de 120 expériences tire des multiplicateurs dans les plages documentées et rejoue
votre parcours ET sa référence sous chaque même configuration. Les tirages sont indépendants,
non estimés statistiquement ; ils n’intègrent pas toutes les corrélations ou incertitudes.

Un résultat favorable n’est pas un test causal en population réelle. Une calibration,
un historique indépendant, une comparaison avec d’autres structures et une revue critique
sont nécessaires avant tout usage pour une décision publique réelle.

## 9. Paramètres éditables

| Paramètre | Défaut | Intervalle |
|---|---:|---:|
| Sensibilité climatique ECS | 3,1 °C | 1,8–6 |
| Coefficient de dommage | 0,00236 | 0,0005–0,02 |
| Rendement des investissements/recherche | 1 | 0–2 |
| Réactions fiscales | 0,35 | 0–1 |
| Efficacité de l’évaluation | 1 | 0–1,5 |
| Pression matérielle | 1 | 0,2–2,5 |
| Progrès autonome annuel | 0,9 % | 0–2,5 % |
| Coût de transition | 1 | 0,4–2,5 |
| Multiplicateur de délais | 1 | 0,5–2,5 |
| Effort extérieur (mode France) | 40 % | 0–95 % |

La liste complète des décisions, bornes, formules et états est dans `sources/src/engine.js`.
La version du moteur et chaque décision sont inscrites dans les sauvegardes.

## 10. Références primaires et code consulté

1. Barrage, L. & Nordhaus, W. (2024), *Policies, projections, and the social cost of carbon:
   Results from the DICE-2023 model*, PNAS. https://doi.org/10.1073/pnas.2312030121
2. Kellett, C. M., Weller, S. R., Faulwasser, T., Grüne, L. & Semmler, W. (2019),
   *Feedback, Dynamics, and Optimal Control in Climate Economics*.
   https://arxiv.org/abs/1812.08066 ; code https://github.com/cmkellett/MPC-DICE
3. Meadows et al., *Limits to Growth: The 30-Year Update*, présentation par les auteurs :
   https://donellameadows.org/archives/a-synopsis-limits-to-growth-the-30-year-update/
4. Vanwynsberghe, C. (2021), PyWorld3 : https://github.com/cvanwynsberghe/pyworld3
5. Folini et al., *The Climate in Climate Economics* : https://arxiv.org/abs/2107.06162
6. Nebel et al. (2024), *Recalibration of limits to growth* : https://doi.org/10.1111/jiec.13442

Sources consultées le 13 octobre 2026. Les équations du jeu sont réécrites en JavaScript.
Aucune bibliothèque externe de ces modèles n’est embarquée. Aucun auteur ou organisme cité
n’a approuvé ni validé le jeu, ses coefficients ajoutés ou la doctrine de Résilience partagée.
