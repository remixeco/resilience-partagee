/* HORIZONS COMMUNS — moteur pédagogique 1.0.0.
 * Code original, construit pour Résilience partagée (2026).
 * Équations climat : forme DICE-2016 (Nordhaus ; Kellett et al. 2019).
 * Stocks et rétroactions matérielles : inspiration World3, PAS sa reproduction.
 * Les modules sociaux/fiscaux et l'initialisation sont des hypothèses de jeu.
 * Aucune calibration France, aucune optimisation normative, aucune prévision.
 */
(function(root,factory){ const api=factory(); if(typeof module==='object'&&module.exports) module.exports=api; else root.ResilienceEngine=api; })(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const VERSION='1.0.0'; const DT=5, START=2025, END=2100, TURNS=(END-START)/DT;
const clamp=(x,a,b)=>Math.min(b,Math.max(a,x));
const copy=x=>JSON.parse(JSON.stringify(x));
const POLICIES=[
 {id:'tax',name:'Prélèvement général',min:15,max:60,step:1,unit:'% de production',group:'budget',icon:'coins',desc:'Finance les services et investissements. Une hausse peut réduire l’investissement privé selon l’hypothèse choisie.',delay:'Effet budgétaire immédiat',origin:'Ajout de jeu'},
 {id:'progress',name:'Contribution progressive',min:0,max:6,step:.5,unit:'points de production',group:'budget',icon:'balance',desc:'Prélèvement supplémentaire concentré sur les revenus élevés. Rendement diminué par les réactions supposées ; incidence finale simplifiée.',delay:'Effet immédiat ; répartition graduelle',origin:'Ajout de jeu'},
 {id:'services',name:'Services essentiels',min:5,max:30,step:1,unit:'% de production',group:'budget',icon:'hospital',desc:'Finance les équipes, l’entretien et les services. Les capacités mettent du temps à se développer ; l’argent ne les crée pas instantanément.',delay:'Environ 15 ans pour les capacités',origin:'Ajout de jeu'},
 {id:'transfers',name:'Protection des revenus',min:0,max:14,step:1,unit:'% de production',group:'budget',icon:'people',desc:'Transferts entre groupes : ils modifient la répartition, pas la quantité de biens par eux-mêmes. Ils sont comptés dans le budget public, pas une seconde fois dans la production.',delay:'Budget immédiat ; répartition 5–10 ans',origin:'Ajout de jeu'},
 {id:'invest',name:'Infrastructures productives',min:0,max:12,step:.5,unit:'% de production',group:'capacity',icon:'factory',desc:'Augmente le capital public après usure. Un programme peut coûter aujourd’hui et ne porter ses effets qu’aux tours suivants.',delay:'5 ans puis accumulation',origin:'Accumulation du capital + ajout de jeu'},
 {id:'research',name:'Recherche et compétences',min:0,max:6,step:.5,unit:'% de production',group:'capacity',icon:'book',desc:'Soutient progressivement les compétences et la productivité. Le rendement est une hypothèse modifiable, pas une recette fiscale garantie.',delay:'5–15 ans',origin:'Ajout de jeu'},
 {id:'audit',name:'Évaluation et coordination',min:0,max:3,step:.25,unit:'% de production',group:'capacity',icon:'search',desc:'Peut améliorer l’exécution des investissements, avec délai et coût administratif. Son efficacité peut être réglée à zéro dans les hypothèses.',delay:'10 ans',origin:'Ajout de jeu'},
 {id:'mu',name:'Cible de décarbonation',min:0,max:95,step:5,unit:'% des émissions évitables',group:'planet',icon:'bolt',desc:'Réduction visée par rapport aux émissions sans cet effort, pas part réelle d’énergies renouvelables. L’effort a un coût croissant et une mise en œuvre progressive.',delay:'Transition effective sur plusieurs tours',origin:'Forme DICE, déploiement ajouté'},
 {id:'circular',name:'Sobriété matérielle et sols',min:0,max:6,step:.5,unit:'% de production',group:'planet',icon:'leaf',desc:'Investit dans la moindre utilisation de matières, les sols et l’alimentation. Réduit progressivement les besoins d’extraction ; ne recrée pas les ressources épuisées.',delay:'5–15 ans',origin:'Inspiration World3 + ajout de jeu'},
 {id:'resilience',name:'Réserves et adaptation',min:0,max:6,step:.5,unit:'% de production',group:'planet',icon:'shield',desc:'Constitue des capacités de secours et diminue certaines pertes lors des chocs. Coûte aussi lorsque la crise n’arrive pas. Ne supprime pas le réchauffement.',delay:'5–15 ans',origin:'Ajout de jeu'},
 {id:'diversity',name:'Diversification des échanges',min:0,max:100,step:5,unit:'% d’effort',group:'planet',icon:'network',desc:'Réduit l’exposition à un choc d’approvisionnement. Son coût logistique augmente. Le modèle ne représente ni tous les partenaires ni les chaînes de valeur.',delay:'5–10 ans',origin:'Ajout de jeu'}
];
const BASE={tax:36,progress:1,services:19,transfers:8,invest:4,research:1.5,audit:.5,mu:25,circular:1,resilience:1,diversity:25};
const PRESETS={
 continuity:{name:'Continuité',short:'Point de comparaison',p:BASE,desc:'Les mêmes réglages tout au long du siècle. Une référence fictive, pas la politique française actuelle.'},
 production:{name:'Production d’abord',short:'Capital & initiative',p:{...BASE,tax:29,progress:0,services:14,transfers:4,invest:7,research:3,audit:.25,mu:15,circular:.5,resilience:.5,diversity:15},desc:'Moins de prélèvements et transferts ; davantage de capital et de recherche.'},
 social:{name:'Services & redistribution',short:'Accès & revenus',p:{...BASE,tax:46,progress:4,services:26,transfers:12,invest:4,research:2,audit:1,mu:30,circular:1.5,resilience:1,diversity:25},desc:'Priorité aux services et à la répartition, financée par des contributions plus fortes.'},
 green:{name:'Transition matérielle',short:'Climat & ressources',p:{...BASE,tax:43,progress:2,services:19,transfers:8,invest:4,research:3,audit:1,mu:90,circular:5,resilience:2,diversity:45},desc:'Effort climatique et matériel élevé, dont les coûts de transition sont explicitement comptés.'},
 fiscal:{name:'Discipline budgétaire',short:'Moins d’engagements',p:{...BASE,tax:38,progress:1,services:15,transfers:5,invest:2,research:1,audit:.5,mu:25,circular:.5,resilience:.5,diversity:15},desc:'Réduit les dépenses et l’investissement public pour améliorer le compte financier.'},
 resilience:{name:'Résilience partagée',short:'La proposition à tester',p:{...BASE,tax:43,progress:3,services:21,transfers:9,invest:5,research:2.5,audit:1.5,mu:70,circular:3,resilience:3,diversity:60},desc:'Une traduction chiffrée fictive de la doctrine : capacités, répartition, anticipation et évaluation. Aucun bonus caché.'}
};
const SCENARIOS={
 reference:{name:'Un siècle à construire',tag:'Découverte',desc:'Pas de crises ponctuelles imposées. Climat, usure et ressources continuent d’évoluer.',shockScale:0,rate:.024,resource:1,productivity:1},
 energy:{name:'La route se ferme',tag:'Approvisionnement',desc:'Un choc d’approvisionnement en 2030 et une nouvelle tension en 2050.',shockScale:1,rate:.024,resource:.85,productivity:1},
 debt:{name:'Des comptes sous tension',tag:'Financement',desc:'Endettement initial plus élevé et refinancement durablement plus coûteux.',shockScale:.6,rate:.04,resource:1,productivity:1,debt:140},
 climate:{name:'Le prix de l’attente',tag:'Climat',desc:'Dommages plus sensibles à la température et coût des épisodes extrêmes renforcé.',shockScale:.8,rate:.024,resource:1,productivity:1,damage:1.8},
 innovation:{name:'La promesse technologique',tag:'Innovation',desc:'Recherche potentiellement plus productive, mais les ressources restent finies.',shockScale:.5,rate:.024,resource:1.2,productivity:1.3},
 polycrisis:{name:'Crises en chaîne',tag:'Défi',desc:'Approvisionnement, santé, taux et récoltes se tendent, parfois simultanément.',shockScale:1.5,rate:.035,resource:.75,productivity:.8}
};
const PARAMS={ecs:3.1,damage:.00236,returns:1,taxResponse:.35,delivery:1,resourcePressure:1,tfp:.009,climateCost:1,lag:1,worldEffort:40,structure:'quadratic',coupling:'hybrid'};
const METRICS={
 output:{name:'Production',unit:'indice · départ ≈ 100',digit:0,desc:'Biens et services disponibles après pertes et coût réel de la décarbonation. Indice de jeu, pas PIB français en euros.'},
 consumption:{name:'Consommation par personne',unit:'indice · départ = 100',digit:0,desc:'Ce qui reste après les usages publics réels et l’investissement privé, rapporté à la population. Les transferts ne sont pas une nouvelle production.'},
 access:{name:'Accès aux besoins',unit:'indice pédagogique / 100',digit:0,desc:'Moyenne harmonique de trois composantes : biens accessibles, services et alimentation. Cet indicateur construit n’est ni un taux de pauvreté ni un indice officiel.'},
 debtRatio:{name:'Engagements publics nets',unit:'% de production annuelle',digit:0,desc:'Dette nette fictive du secteur public / production. Une valeur négative représente des actifs nets. Le bloc financier n’est pas un modèle bancaire complet.'},
 temp:{name:'Réchauffement mondial',unit:'°C · au-dessus du préindustriel',digit:2,desc:'Température du module climatique de forme DICE-2016. État initial scénarisé, pas température observée ou prévision officielle.'},
 resources:{name:'Ressources non renouvelables',unit:'% du stock initial',digit:1,desc:'Stock agrégé fictif restant. Ni réserves minières mondiales mesurées ni somme physique de tous les matériaux.'},
 food:{name:'Couverture alimentaire',unit:'% du besoin de référence',digit:0,desc:'Production alimentaire modélisée / besoin agrégé. 100 % = référence du jeu, pas distribution garantie à chaque personne.'},
 emissions:{name:'Émissions mondiales',unit:'GtCO₂ / an · simulation',digit:1,desc:'Flux mondial de CO₂ alimentant les réservoirs de carbone. En mode France, il inclut une trajectoire extérieure distincte.'},
 inequality:{name:'Écart de revenus',unit:'rapport hauts / bas revenus',digit:1,desc:'Rapport synthétique entre groupes fictifs. Les effets des transferts et prélèvements sont postulés, non estimés pour la France.'},
 population:{name:'Population',unit:'indice · départ = 100',digit:1,desc:'Démographie agrégée dépendant du temps, des conditions de vie et de la nourriture. Sans cohortes d’âge détaillées : ce n’est pas la démographie complète de World3.'},
 pollution:{name:'Pollution persistante',unit:'indice · départ = 100',digit:0,desc:'Polluant non-CO₂ abstrait, distinct du carbone. Production, accumulation et assimilation lente ; ce n’est pas un indicateur mesuré.'},
 service:{name:'Capacités de service',unit:'indice · départ = 100',digit:0,desc:'Capacité réelle par personne, qui se construit et s’use. La dépense actuelle ne donne pas instantanément une équipe formée.'}
};
function hash(seed,n){let a=(Number(seed)>>>0)^Math.imul(n+17,0x9e3779b9);a=Math.imul(a^(a>>>16),0x21f0aaad);a=Math.imul(a^(a>>>15),0x735a2d97);return ((a^(a>>>15))>>>0)/4294967296;}
function cleanPolicy(p){let o={};for(const x of POLICIES){const n=Number(p?.[x.id]);o[x.id]=clamp(Number.isFinite(n)?n:BASE[x.id],x.min,x.max);}return o;}
function cleanConfig(c={}){
 c=(c && typeof c==='object')?c:{};
 const o={scenario:Object.hasOwn(SCENARIOS,c.scenario)?c.scenario:'reference',scope:c.scope==='france'?'france':'world',seed:clamp(Math.round(Number(c.seed)||42),1,2147483646),params:{...PARAMS},mission:{access:70,debt:150,temp:2.5,resources:20}};
 const bounds={ecs:[1.8,6],damage:[.0005,.02],returns:[0,2],taxResponse:[0,1],delivery:[0,1.5],resourcePressure:[.2,2.5],tfp:[0,.025],climateCost:[.4,2.5],lag:[.5,2.5],worldEffort:[0,95]};
 for(const[k,b]of Object.entries(bounds)){const v=Number(c.params?.[k]);if(Number.isFinite(v))o.params[k]=clamp(v,...b);}
 if(['quadratic','convex'].includes(c.params?.structure))o.params.structure=c.params.structure;
 if(['hybrid','climate','material'].includes(c.params?.coupling))o.params.coupling=c.params.coupling;
 for(const[k,b]of Object.entries({access:[30,95],debt:[50,300],temp:[1.5,5],resources:[5,80]})){const v=Number(c.mission?.[k]);if(Number.isFinite(v))o.mission[k]=clamp(v,...b);}
 return o;
}
// Un pas de 5 ans. Matrice conservant le carbone : les colonnes somment à 1.
function carbonStep(m,emissions){const b12=.12,b23=.007,b21=b12*588/360,b32=b23*360/1720;return[(1-b12)*m[0]+b21*m[1]+DT*emissions/3.667,b12*m[0]+(1-b21-b23)*m[1]+b32*m[2],b23*m[1]+(1-b32)*m[2]];}
function climateStep(m,t,ocean,emissions,year,ecs=3.1){const nm=carbonStep(m,emissions),forcing=3.6813*Math.log2(nm[0]/588)+.5+.5*clamp((year+DT-2015)/85,0,1);return{carbon:nm,temp:t+.1005*(forcing-3.6813/ecs*t-.088*(t-ocean)),ocean:ocean+.025*(t-ocean),forcing};}
function init(config={}){
 const cfg=cleanConfig(config),sc=SCENARIOS[cfg.scenario];
 return{year:START,turn:0,K:250,Kpub:90,A:1,H:1,S:1,R:.2,V:.25,G:.6,mu:.12,material:1,land:1,agri:1,N:100*sc.resource,N0:100*sc.resource,P:1,L:1,debt:sc.debt||100,carbon:[910,480,1750],temp:1.25,ocean:.18,prevOutput:100,prevTax:BASE.tax,prevSpending:28,baseConsumption:55,cfg,history:[],policies:[],journal:[]};
}
function eventAt(s){const{scenario,seed}=s.cfg,scale=SCENARIOS[scenario].shockScale;if(!scale)return{title:'Un tour sans crise ponctuelle',kind:'none',loss:0,rate:0,food:0,description:'L’usure, le climat et les ressources continuent d’agir.',cost:0};
 let kind='none';const t=s.turn;if(scenario==='energy'&&[1,5].includes(t))kind='supply';else if(scenario==='debt'&&[1,4,8].includes(t))kind='rates';else if(scenario==='climate'&&[3,7,11].includes(t))kind='harvest';else if(scenario==='polycrisis'&&[1,4,7,10,13].includes(t))kind=['supply','health','compound','harvest','compound'][[1,4,7,10,13].indexOf(t)];else if(hash(seed,t*9)<.18)kind=['supply','health','harvest'][Math.floor(hash(seed,t*9+1)*3)];
 const sev=(.8+.4*hash(seed,t*9+2))*scale;
 const defs={none:['Usure silencieuse',0,0,0,'Pas de choc ponctuel. L’entretien et les contraintes de fond restent décisifs.'],supply:['La route des matières se ferme',.095,0,0,'Un fournisseur majeur est indisponible. La diversification peut limiter la perte, sans la supprimer.'],rates:['Le refinancement devient plus cher',.012,.018,0,'Le coût du financement augmente pour ce tour. Une réserve matérielle ne neutralise pas ce choc de taux.'],health:['Une crise sanitaire ralentit l’activité',.075,0,0,'L’activité se contracte. Services et capacités de secours peuvent amortir une partie des pertes.'],harvest:['Des récoltes sous pression',.025,0,.17,'La production alimentaire subit un choc supplémentaire. Les sols et capacités de secours comptent.'],compound:['Plusieurs fragilités se cumulent',.13,.012,.14,'Tensions sur les matières, les récoltes et les taux : les protections doivent fonctionner ensemble.']};
 const d=defs[kind];return{kind,title:d[0],loss:d[1]*sev,rate:d[2]*sev,food:d[3]*sev,description:d[4],cost:0};
}
function budget(s,p,Y,ev,action){const q=s.cfg.params,effRate=(p.tax+p.progress*(1-q.taxResponse))/100;const receipts=Y*effRate;const baseRate=SCENARIOS[s.cfg.scenario].rate;const premium=.008*Math.max(0,s.debt/Math.max(1,Y)-1.2)**1.35;const r=s.debt<0?.012:Math.min(.18,baseRate+premium+ev.rate);const interest=r*s.debt;const logistics=.012*(p.diversity/100)**2*Y;const emergency=ev.kind==='none'?0:[0,.012,.032][action]*Y;
 const rates=['services','invest','research','audit','circular','resilience'];const items=Object.fromEntries(rates.map(k=>[k,Y*p[k]/100]));items.transfers=Y*p.transfers/100;items.logistics=logistics;items.emergency=emergency;items.interest=interest;
 const purchases=rates.reduce((a,k)=>a+items[k],0)+logistics+emergency;const spending=purchases+items.transfers+interest;return{receipts,spending,purchases,items,interest,rate:r,balance:receipts-spending,effRate,emergency};}
function step(old,policy,action=0){if(old.year>=END)throw Error('La partie est terminée.');let s=copy(old),p=cleanPolicy(policy);action=clamp(Math.round(Number(action)||0),0,2);const cfg=s.cfg,q=cfg.params,sc=SCENARIOS[cfg.scenario],ev=eventAt(s),climateOn=q.coupling!=='material',materialsOn=q.coupling!=='climate';
 const eff=clamp(.55+.45*s.G,.35,1);const resourceFraction=s.N/s.N0;
 const scarcity=materialsOn?clamp(1-.50*q.resourcePressure*(1-resourceFraction)**3,.05,1):1;
 const thermal=q.structure==='convex'?q.damage*s.temp*s.temp+.0015*Math.max(0,s.temp-2)**4:q.damage*s.temp*s.temp;
 const damage=climateOn?clamp(thermal*(sc.damage||1)/(1+thermal*(sc.damage||1))*(1-.35*s.R),0,.85):0;
 const response=[0,.18,.38][action];const shockMitigation=ev.kind==='supply'?(.5*s.V+.22*s.R):(.18*clamp(s.S,0,2)+.32*s.R);
 const shockLoss=clamp(ev.loss*(1-clamp(shockMitigation,0,.75))*(1-response),0,.65);
 const foodBefore=1.18*s.agri*s.land/Math.max(.3,s.L);const foodPenalty=materialsOn?clamp(foodBefore/.85,.35,1):1;
 const baseProd=100*s.A*(s.K/250)**.3*(s.Kpub/90)**.08*s.H**.18*s.L**.7;
 const demand=clamp(1+.20*(p.services-BASE.services)/100+.08*(p.transfers-BASE.transfers)/100-.1*(p.tax-BASE.tax)/100,.9,1.06);
 const grossPotential=baseProd*scarcity*foodPenalty*demand*(1-shockLoss);
 const theta=.075*q.climateCost*Math.exp(-.006*(s.year-START));const abatement=climateOn?clamp(theta*s.mu**2.6,0,.4):0;
 // A finite material stock constrains realised output, not just its price.
 // At most 95% of the remaining abstract stock is mobilisable in one 5-year turn.
 // Explicit reduced-model assumption; this is NOT a World3 lookup function.
 const materialPerOutput=DT*.82*q.resourcePressure*s.material*(1-.20*s.mu)/100;
 const resourceCapacity=materialsOn?.95*s.N/materialPerOutput:Infinity;
 const unconstrainedY=grossPotential*(1-damage)*(1-abatement);
 const Y=Math.max(0,Math.min(unconstrainedY,resourceCapacity));
 const gross=grossPotential*(unconstrainedY>0?Y/unconstrainedY:0);
 const b=budget(s,p,Y,ev,action);
 // Usages matériels : les transferts et intérêts ne sont pas soustraits deux fois.
 if(b.purchases/Math.max(Y,1e-12)>.73)throw Error('Les usages publics réels dépassent 73 % de la production. Réduis certains postes avant de jouer.');
 const privateShare=clamp(.18-q.taxResponse*.28*(b.effRate-.37)+.008*(s.H-1),.04,.3);
 const Iprivate=Math.min(privateShare*Y,Math.max(0,Y-b.purchases-.12*Y));const C=Math.max(0,Y-b.purchases-Iprivate);
 const rawEmissions=38*(gross/100)*Math.exp(-.012*(s.year-START))*(1-s.mu);
 let worldEmissions=rawEmissions+2.6*Math.exp(-.025*(s.year-START));
 if(cfg.scope==='france'){const outerMu=.12+(q.worldEffort/100-.12)*(1-Math.exp(-(s.year-START)/20));worldEmissions=.01*rawEmissions+.99*38*Math.exp(.006*(s.year-START))*(1-outerMu)+2.6*Math.exp(-.025*(s.year-START));}
 if(!climateOn)worldEmissions=0;
 const ns=copy(s);ns.turn++;ns.year+=DT;
 const cd=climateOn?climateStep(s.carbon,s.temp,s.ocean,worldEmissions,s.year,q.ecs):{carbon:s.carbon.slice(),temp:s.temp,ocean:s.ocean,forcing:0};Object.assign(ns,cd);
 const investEfficiency=eff*q.returns;
 ns.K=s.K*.955**DT+DT*Iprivate;
 ns.Kpub=s.Kpub*.965**DT+DT*b.items.invest*investEfficiency;
 const educationTarget=.60+(p.services/19)*.36+(p.research/1.5)*.06*q.returns;
 ns.H=clamp(s.H+(1-Math.exp(-DT/(18*q.lag)))*(educationTarget-s.H),.3,2.2);
 const serviceTarget=(p.services/19)*(Y/100)/Math.max(.3,s.L)*(.7+.3*eff);
 ns.S=clamp(s.S+(1-Math.exp(-DT/(15*q.lag)))*(serviceTarget-s.S),.1,4);
 ns.G=clamp(s.G+(1-Math.exp(-DT/(12*q.lag)))*(.40+q.delivery*.45*(1-Math.exp(-p.audit/1.2))-s.G),.1,.95);
 ns.R=clamp(s.R*.96**DT+DT*(p.resilience/100)*2.4*eff*q.returns,0,.95);
 ns.V=clamp(s.V+(1-Math.exp(-DT/(8*q.lag)))*(p.diversity/100-s.V),0,1);
 ns.mu=clamp(s.mu+(1-Math.exp(-DT/(12*q.lag)))*(p.mu/100-s.mu),0,.98);
 ns.A=s.A*Math.exp(DT*(q.tfp*sc.productivity+.0018*p.research*eff*q.returns));
 ns.material=Math.max(.06,s.material*Math.exp(-DT*(.003+.0045*p.circular*eff*q.returns)));
 ns.agri=s.agri*Math.exp(DT*(.002+.0008*p.research*eff*q.returns+.0006*p.circular*eff));
 const extraction=materialsOn?Math.min(s.N,DT*.82*q.resourcePressure*(Y/100)*s.material*(1-.20*s.mu)):0;
 ns.N=Math.max(0,s.N-extraction);
 ns.P=materialsOn?Math.max(0,s.P+DT*(.065*(Y/100)*s.material*(1-.2*s.mu)-.055*s.P/(1+.05*s.P))):s.P;
 ns.land=materialsOn?clamp(s.land+DT*(.012*(1-s.land)+.00065*p.circular*eff-.0018*s.P-.0015*Math.max(0,s.temp-1.25)**2),.15,1.12):s.land;
 let Lgrowth=cfg.scope==='france'?.0005:.010*(1-s.L/1.45);
 if(materialsOn)Lgrowth-=.035*Math.max(0,.85-foodBefore);Lgrowth-=.003*Math.max(0,damage-.08);
 ns.L=Math.max(.1,s.L*Math.exp(DT*Lgrowth));
 // Identité exacte pour 5 paiements annuels constants et taux fixe au tour.
 const ann=b.spending-b.interest-b.receipts;
 ns.debt=s.debt*(1+b.rate)**DT+ann*(((1+b.rate)**DT-1)/b.rate);
 const ratioTarget=clamp(7.5-.23*p.transfers-.22*p.progress*(1-q.taxResponse)+.035*(p.tax-36)+.35*Math.max(0,1-s.S),1.5,12);
 const oldI=s.history.length?s.history.at(-1).inequality:6;
 const inequality=oldI+(1-Math.exp(-DT/8))*(ratioTarget-oldI);
 const baseC=s.baseConsumption||C;ns.baseConsumption=baseC;const consumption=100*(C/ns.L)/baseC;
 const affordability=clamp(consumption/(1+.035*(inequality-6)),0,160);
 const food=materialsOn?100*1.18*ns.agri*ns.land/ns.L*(1-ev.food*(1-.55*s.R)*(1-response)):118;
 const components=[clamp(affordability/1.2,.0001,100),clamp(ns.S*82,.0001,100),clamp(food/1.15,.0001,100)];
 const access=3/components.reduce((a,v)=>a+1/v,0);
 const annualAverageInterest=(ns.debt-s.debt)/DT-ann;
 const snapshot={year:ns.year,output:Y,consumption,access,debtRatio:100*ns.debt/Math.max(Y,1e-9),temp:ns.temp,resources:100*ns.N/ns.N0,food,emissions:worldEmissions,inequality,population:100*ns.L,pollution:100*ns.P,service:100*ns.S,
 balance:b.balance,balance5:(s.debt-ns.debt)/DT,receipts:b.receipts,spending:b.spending,interest:b.interest,averageInterest:annualAverageInterest,rate:b.rate*100,privateInvestment:Iprivate,consumptionReal:C,publicUses:b.purchases,climateLoss:gross*damage,abatementCost:gross*(1-damage)*abatement,scarcityLoss:baseProd*(1-scarcity)+Math.max(0,unconstrainedY-Y),shockLoss:baseProd*shockLoss,extraction,carbon:ns.carbon.slice(),items:b.items,mu:ns.mu*100,capPublic:ns.Kpub,capPrivate:ns.K,coordination:ns.G*100,
 audit:{carbon:ns.carbon.reduce((a,b)=>a+b,0)-s.carbon.reduce((a,b)=>a+b,0)-(climateOn?DT*worldEmissions/3.667:0),goods:Y-(C+Iprivate+b.purchases),debt:ns.debt-(s.debt*(1+b.rate)**DT+ann*((1+b.rate)**DT-1)/b.rate),resource:s.N-ns.N-extraction}};
 ns.prevOutput=Y;ns.prevTax=p.tax;ns.prevSpending=b.purchases/Math.max(Y,1e-9)*100;ns.history.push(snapshot);ns.policies.push({p,action});ns.journal.push({year:ns.year,event:ev,action,outputDelta:(Y/s.prevOutput-1)*100,oldAccess:s.history.at(-1)?.access||82,newAccess:access,budget:b.balance,climateLoss:snapshot.climateLoss,scarcityLoss:snapshot.scarcityLoss,shockLoss:snapshot.shockLoss,abatementCost:snapshot.abatementCost,coordination:ns.G});
 for(const key of ['K','Kpub','A','H','S','R','V','G','mu','material','land','agri','N','P','L','debt','temp','ocean'])if(!Number.isFinite(ns[key]))throw Error('Domaine numérique dépassé : '+key);
 return ns;
}
function startPoint(s){return{year:START,output:100,consumption:100,access:82,debtRatio:s.debt,temp:s.temp,resources:100,food:118,emissions:36,population:100,inequality:6,pollution:100,service:100};}
function trajectory(s){return[startPoint(init(s.cfg)),...s.history];}
function simulate(config,p,sequence=[]){let s=init(config);for(let i=0;i<TURNS;i++){const a=sequence[i];s=step(s,a?.p||p,a?.action||0);}return s;}
function mission(s){const d=s.history.at(-1)||startPoint(s),g=s.cfg.mission;return[{name:'Accès aux besoins',met:d.access>=g.access,value:d.access,target:'≥ '+g.access,unit:'/100'},{name:'Engagements publics',met:d.debtRatio<=g.debt,value:d.debtRatio,target:'≤ '+g.debt,unit:'%'},{name:'Réchauffement mondial',met:d.temp<=g.temp,value:d.temp,target:'≤ '+g.temp,unit:'°C'},{name:'Ressources restantes',met:d.resources>=g.resources,value:d.resources,target:'≥ '+g.resources,unit:'%'}];}
function quantile(a,q){const x=a.slice().sort((a,b)=>a-b),k=(x.length-1)*q,i=Math.floor(k);return x[i]+(x[Math.ceil(k)]-x[i])*(k-i);}
function ensemble(config,p,sequence=[],count=120){const cfg=cleanConfig(config),res=[];for(let i=0;i<count;i++){
 const c=copy(cfg),noise=j=>hash(cfg.seed+9137,i*31+j);c.seed=1+Math.floor(noise(1)*1000000);
 c.params.ecs=clamp(cfg.params.ecs*(.75+.5*noise(2)),1.8,6);c.params.damage=cfg.params.damage*(.5+1.5*noise(3));c.params.returns=clamp(cfg.params.returns*(.5+noise(4)),0,2);c.params.resourcePressure=cfg.params.resourcePressure*(.6+.8*noise(5));c.params.taxResponse=clamp(cfg.params.taxResponse+(.5-noise(6))*.5,0,1);c.params.tfp=cfg.params.tfp*(.6+.8*noise(7));c.params.delivery=clamp(cfg.params.delivery*(.5+noise(8)),0,1.5);c.params.lag=cfg.params.lag*(.75+.75*noise(9));c.params.structure=noise(10)>.5?'quadratic':'convex';
 const user=simulate(c,p,sequence),base=simulate(c,BASE);res.push({user:user.history.at(-1),base:base.history.at(-1),goals:mission(user).filter(x=>x.met).length});}
 const summary={};for(const k of Object.keys(METRICS)){const v=res.map(r=>r.user[k]),delta=res.map(r=>r.user[k]-r.base[k]);summary[k]={p10:quantile(v,.1),p50:quantile(v,.5),p90:quantile(v,.9),delta50:quantile(delta,.5),nGreater:delta.filter(x=>x>0).length,nLess:delta.filter(x=>x<0).length};}return{count,summary,allGoals:res.filter(x=>x.goals===4).length,raw:res};}
function replay(save){if(!save||save.format!=='resilience-horizons'||save.version!==VERSION)throw Error('Ce fichier ne correspond pas à cette version du jeu.');if(!Array.isArray(save.decisions)||save.decisions.length>TURNS)throw Error('Historique invalide.');let s=init(save.config);for(const d of save.decisions){if(!d||typeof d.p!=='object')throw Error('Décision invalide.');s=step(s,d.p,d.action);}return{state:s,policy:cleanPolicy(save.policy||save.decisions.at(-1)?.p||BASE)};}
function serialize(s,p){return{format:'resilience-horizons',version:VERSION,config:s.cfg,decisions:s.policies,policy:cleanPolicy(p)};}
// Bac DICE-2016 : simulation avant de politiques imposées, SANS optimiseur.
// Forme et paramètres référencés ; nouvelles valeurs choisies par le joueur.
function diceReference(mu=.5,savings=.25,ecs=3.1,damage=.00236){let x={year:2015,K:223,A:5.115,L:7403,sigma:35.85/(105.5*.97),land:2.6,carbon:[851,460,1740],temp:.85,ocean:.0068};let out=[];
 for(let i=0;i<=27;i++){const control=.03+(mu-.03)*(1-Math.exp(-i/4)),Q=x.A*x.K**.3*(x.L/1000)**.7,theta=x.sigma*550*.975**i/(1000*2.6),Y=Q/(1+damage*x.temp*x.temp)*(1-theta*control**2.6),E=x.sigma*(1-control)*Q+x.land;out.push({year:x.year,output:Q,net:Y,population:x.L/1000,consumption:1000*(1-savings)*Y/x.L,emissions:E,temp:x.temp,capital:x.K,mu:control*100});const clim=climateStep(x.carbon,x.temp,x.ocean,E,x.year,ecs);x={...x,...clim,year:x.year+5,K:.9**5*x.K+5*savings*Y,A:x.A/(1-.076*Math.exp(-.005*5*i)),L:x.L*(11500/x.L)**.134,sigma:x.sigma*Math.exp(-.0152*(.999**5)**i*5),land:2.6*.885**(i+1)};}return out;}
return{VERSION,DT,START,END,TURNS,POLICIES,BASE,PRESETS,PARAMS,SCENARIOS,METRICS,init,step,simulate,trajectory,mission,eventAt,budget,ensemble,serialize,replay,cleanPolicy,cleanConfig,carbonStep,climateStep,diceReference,hash,quantile};
});
