const assert=require('assert');
const E=require('../src/engine.js'),M=require('../src/discovery-model.js');
let leaves=0,steps=0,audits=0,maxResidual=0;
function walk(g){
 if(g.picks.length===6){leaves++;const round=M.restore(M.save(g));assert.deepStrictEqual(round,g);return;}
 const opts=M.options(g);assert.equal(opts.length,3);
 const event=E.eventAt(g.state);assert.equal(event.kind,[1,5].includes(g.picks.length)?'supply':'none');
 opts.forEach((o,i)=>{const next=M.play(g,i),direct=E.step(g.state,o.policy,o.action);assert.deepStrictEqual(next.state,direct);steps++;
 const d=next.state.history.at(-1);for(const key of Object.keys(E.METRICS))assert(Number.isFinite(d[key]),key);
 for(const [k,v]of Object.entries(d.audit)){assert(Math.abs(v)<1e-7,k);maxResidual=Math.max(maxResidual,Math.abs(v));audits++;}
 assert(d.resources>=0&&d.resources<=100);const b=M.budget100(next);assert(Math.abs(b.in-b.out-b.net)<1e-8);
 assert(d.access>=0&&d.access<=100.0001);walk(next);
 });
}
walk(M.initial());
const first=M.options(M.initial());assert.equal(first[0].policy.tax,E.BASE.tax+3);assert.equal(first[2].policy.tax,E.BASE.tax);assert.equal(first[1].policy.invest,E.BASE.invest-2);
assert.throws(()=>M.restore({format:'horizons-decouverte',version:M.VERSION,choices:['0']}));assert.throws(()=>M.restore({format:'horizons-decouverte',version:M.VERSION,choices:[0,0,0,0,0,0,0]}));
const out={all_paths:leaves,transitions_checked:steps,accounting_checks:audits,maxResidual,engine_unmodified:true,deterministic_scenarios:true,replay_exact:true,invalid_import_rejected:true};
console.log(JSON.stringify(out,null,2));require('fs').writeFileSync(require('path').join(__dirname,'model-results.json'),JSON.stringify(out,null,2));
