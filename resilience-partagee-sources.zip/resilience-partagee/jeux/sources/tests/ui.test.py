from playwright.sync_api import sync_playwright
from pathlib import Path
import json
B=Path(__file__).resolve().parent.parent
results={'errors':[],'widths':[],'checks':[]}
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':1050},device_scale_factor=1)
 page.on('pageerror',lambda e:results['errors'].append(str(e)))
 page.set_content((B/'dist/jeu.html').read_text(), wait_until='load');page.wait_for_timeout(200)
 page.screenshot(path=str(B/'tests/welcome-desktop.png'),full_page=True)
 page.click('#start');assert page.locator('#commit').is_disabled()
 page.locator('input[name="decision"]').nth(0).check();assert page.locator('#commit').is_enabled()
 page.screenshot(path=str(B/'tests/decision-desktop.png'),full_page=True)
 page.click('#commit');assert page.evaluate('DiscoveryTest.getState().choices.length')==1
 page.screenshot(path=str(B/'tests/result-desktop.png'),full_page=True)
 page.click('[data-quiz="0"]');assert 'Regardons' in page.locator('#quiz-feedback').inner_text()
 page.click('[data-quiz="1"]');assert 'Oui,' in page.locator('#quiz-feedback').inner_text()
 page.locator('#compare-choices summary').click();page.screenshot(path=str(B/'tests/compare-desktop.png'),full_page=True)
 page.click('[data-retry="2"]');assert page.evaluate('DiscoveryTest.getState().choices[0]')==2
 page.click('[data-action="back"]');assert page.evaluate('DiscoveryTest.getPhase()')=='decision';assert page.evaluate('DiscoveryTest.getState().choices.length')==0
 page.locator('input[name="decision"]').nth(0).check();page.click('#commit')
 for i,n in enumerate([1,0,1,0,1],start=1):
  page.click('[data-action="next"]');assert page.evaluate('DiscoveryTest.getPhase()')=='decision'
  page.locator('input[name="decision"]').nth(n).check();page.click('#commit')
 page.click('[data-action="next"]');assert page.evaluate('DiscoveryTest.getPhase()')=='end'
 page.locator('summary',has_text='Et si nos hypothèses').click();page.click('[data-sensitivity="returns"]');assert 'Rendement' in page.locator('#sensitivity-result').inner_text()
 page.screenshot(path=str(B/'tests/end-desktop.png'),full_page=True)
 before=page.evaluate('JSON.stringify(DiscoveryTest.getState())')
 page.click('#expert-open');page.wait_for_timeout(500)
 frame=page.frame_locator('#expert-frame');assert frame.locator('#year').inner_text()=='2055'
 frame.locator('#advance').click();assert frame.locator('#year').inner_text()=='2060'
 page.click('[data-close="expert-dialog"]');assert page.evaluate('JSON.stringify(DiscoveryTest.getState())')==before
 page.click('[data-help="budget"]');assert page.locator('#help-dialog').is_visible();page.keyboard.press('Escape')
 with page.expect_download() as d:page.click('[data-action="save"]')
 savepath=d.value.path();raw=json.loads(Path(savepath).read_text());assert len(raw['choices'])==6
 page.locator('#load-file').set_input_files(str(savepath));assert page.evaluate('DiscoveryTest.getState().choices.length')==6
 with page.expect_download() as d:page.click('[data-action="report"]')
 assert 'bilan' in d.value.suggested_filename
 page.click('[data-action="share"]');assert 'fichier local' in page.locator('#dialog-body').inner_text();page.keyboard.press('Escape')
 page.click('#textsize');assert page.locator('body').evaluate("el=>el.classList.contains('bigtext')")
 results['checks']+=['six turns completed','choice gate','optional quiz feedback','counterfactual retry','undo','sensitivity','advanced transferred','advanced exploration separate','json save import','report download','local share notice','font size']
 for width in [360,390,580,768,1024,1440]:
  ctx=browser.new_context(viewport={'width':width,'height':880})
  m=ctx.new_page();m.on('pageerror',lambda e:results['errors'].append(str(e)))
  m.set_content((B/'dist/jeu.html').read_text(), wait_until='load');m.click('#start');m.locator('input[name="decision"]').nth(0).check()
  w=m.evaluate('({view:innerWidth,scroll:document.documentElement.scrollWidth})');results['widths'].append(w);assert w['scroll']<=w['view']+1,w
  if width==390:
   m.screenshot(path=str(B/'tests/decision-mobile.png'),full_page=True)
   m.click('#commit');m.screenshot(path=str(B/'tests/result-mobile.png'),full_page=True)
  ctx.close()
 # Site contains the new discoverable game and the original study.
 site=browser.new_page(viewport={'width':1440,'height':1000});site.on('pageerror',lambda e:results['errors'].append(str(e)))
 site.set_content((B/'dist/index.html').read_text(), wait_until='load');site.wait_for_timeout(200)
 site.locator('[data-open-lab]').first.click();site.wait_for_timeout(500)
 sf=site.frame_locator('#lab-gameframe');assert sf.locator('#start').is_visible();sf.locator('#start').click();sf.locator('input[name="decision"]').nth(1).check();sf.locator('#commit').click()
 site.screenshot(path=str(B/'tests/site-integrated.png'),full_page=True)
 site.locator('#lab-close').click();assert site.locator('#lab-dialog').is_hidden()
 results['checks'].append('site integration and close')
 assert not results['errors'],results['errors']
 browser.close()
(B/'tests/ui-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps(results,ensure_ascii=False,indent=2))
