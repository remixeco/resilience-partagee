from pathlib import Path
import base64,re,hashlib,gzip,textwrap,json
B=Path(__file__).resolve().parent;S=B/'src';D=B/'dist';D.mkdir(exist_ok=True)
O=B/'original'
advanced=(O/'jeu.html').read_text()
# The enclosing guided interface passes the current state explicitly; do not
# interpret its own guided-link payload as an old advanced save.
advanced=advanced.replace("if(window.self!==window.top){try{hash=window.top.location.hash;}catch(e){}}",'/* Guided host transfers an explicit validated advanced save on load. */')
advanced=advanced.replace('patternunits=', 'patternUnits=').replace('lineargradient','linearGradient').replace('fedropshadow','feDropShadow').replace('stddeviation=','stdDeviation=')
(D/'laboratoire-avance.html').write_text(advanced)
icons=(O/'sources/src/icons.svg').read_text()
art=(O/'sources/src/district.svg').read_text().replace('patternunits=', 'patternUnits=').replace('lineargradient','linearGradient').replace('fedropshadow','feDropShadow').replace('stddeviation=','stdDeviation=')
rep={'CSS':(S/'discovery.css').read_text(),'ICONS':icons,'DISTRICT':art,'ADVANCED':base64.b64encode(advanced.encode()).decode(),'ENGINE':(S/'engine.js').read_text(),'MODEL':(S/'discovery-model.js').read_text(),'UI':(S/'discovery-ui.js').read_text()}
html=(S/'discovery.template.html').read_text()
for k,v in rep.items():html=html.replace('__'+k+'__',v)
assert not re.search(r'__[A-Z_]+__',html)
(D/'jeu.html').write_text(html)
site=(O/'index.html').read_text()
site,n=re.subn(r'(<script type="application/octet-stream" id="lab-game-payload">)[^<]+(</script>)',lambda m:m[1]+base64.b64encode(html.encode()).decode()+m[2],site,count=1)
assert n==1
portal_match = re.search(r'<section id="laboratoire"[^>]*>.*?</section>', site, re.S)
if not portal_match:
    raise ValueError('Section du laboratoire introuvable')
portal = portal_match.group()
newportal=portal.replace('NOUVEAU · UN LABORATOIRE JOUABLE','NOUVEAU · L’ÉCONOMIE EN JOUANT, PAS À PAS').replace('Une vision à défendre.<br><em>Un monde pour la tester.</em>','Une situation concrète.<br><em>Et vous, que décidez-vous ?</em>').replace('Que se passe-t-il lorsque les bonnes intentions rencontrent un budget, des délais, des ressources limitées et une crise ? Dans <strong>Horizons communs</strong>, prenez les décisions et observez leurs conséquences jusqu’en 2100.','Une école à renforcer, une route qui ferme, un budget à partager. Dans <strong>Horizons communs</strong>, avancez avec six situations simples. Choisissez une carte : le jeu vous explique ensuite ce qui a changé, pourquoi et à quel coût.').replace('Entrer dans le laboratoire','Jouer ma première décision').replace('Comprendre les règles','Comment jouer ?').replace('2025 → 2100','DÉCOUVERTE GUIDÉE').replace('Décider aujourd’hui.<br>Observer demain.','Choisir simplement.<br>Comprendre en faisant.').replace('<b>15</b><span>décisions quinquennales','<b>6</b><span>situations à découvrir').replace('<b>11</b><span>leviers de politique','<b>3</b><span>choix à chaque étape').replace('<b>120</b><span>configurations à éprouver','<b>4</b><span>repères expliqués').replace('Comparer à terrain égal','Revenir en arrière et essayer').replace('Exporter et rejouer ↗','Mode avancé disponible ↗').replace('<b>Jouer</b><p>Choisir les contributions, les services, l’investissement, la transition et les protections. Réagir aux événements.','<b>Commencer sans jargon</b><p>Une situation à la fois, trois choix concrets. Les termes sont expliqués et les détails peuvent être ouverts au besoin.').replace('<b>Comparer</b><p>Opposer six stratégies et votre parcours dans les mêmes conditions. Aucun score politique imposé.','<b>Comprendre le résultat</b><p>Un avant–après, une explication et une petite question facultative. Essayez un autre choix dans les mêmes conditions.').replace('<b>Contredire</b><p>Modifier les rendements, les dommages et les délais. Observer ce qui résiste, et ce qui échoue.','<b>Aller plus loin</b><p>Le laboratoire complet reste accessible : onze leviers, comparaisons et 120 configurations de sensibilité. Les essais avancés restent séparés de la découverte.')
assert portal in site
site=site.replace(portal,newportal,1).replace('Le jeu ↗</a>','Jouer ↗</a>').replace('Tester dans le jeu ↗','Comprendre en jouant ↗')
site=site.replace('Le laboratoire.','Le laboratoire.',1)
(D/'index.html').write_text(site)
# Reuse the user's prior launcher protocol, changing only its payload and metadata.
pub=(S/'publisher.template.command').read_text()
prefix=pub.split('__RESILIENCE_SITE_PAYLOAD__\n',1)[0]
# The first marker is an awk pattern on a longer line, not the payload delimiter.
if len(prefix)>100000:raise ValueError('Publisher payload marker not found')
sha=hashlib.sha256(site.encode()).hexdigest();size=len(site.encode())
prefix=re.sub(r"EXPECTED_SHA='[0-9a-f]+'",f"EXPECTED_SHA='{sha}'",prefix)
prefix=re.sub(r"EXPECTED_SIZE='\d+'",f"EXPECTED_SIZE='{size}'",prefix)
prefix=prefix.replace('53b30e9694c8756180e26c789b23176a60eb437b8b3c22ef123895d297079b97',sha).replace('1570663',str(size))
prefix=prefix.replace('Horizons communs — nouveau site intégré ; manifeste vérifié le 13/10/2026','Horizons communs — parcours guidé ; contenu mis à jour le 13/10/2026')
prefix=prefix.replace('version Horizons communs : site approuvé + laboratoire jouable.','version découverte : site + six situations guidées + laboratoire avancé.').replace('site avec le laboratoire Horizons communs','site avec le jeu guidé Horizons communs')
pub=prefix+'__RESILIENCE_SITE_PAYLOAD__\n'+'\n'.join(textwrap.wrap(base64.b64encode(gzip.compress(site.encode(),mtime=0)).decode(),100))+'\n'
(D/'Publier_Resilience_Facile.command').write_text(pub)
print(json.dumps({'game_bytes':len(html.encode()),'site_bytes':size,'sha256':sha,'publisher_bytes':len(pub.encode()),'engine_unchanged':(S/'engine.js').read_bytes()==(O/'sources/src/engine.js').read_bytes()},indent=2))
