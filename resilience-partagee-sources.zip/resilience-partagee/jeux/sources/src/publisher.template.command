#!/bin/bash
# Horizons communs — nouveau site intégré ; manifeste vérifié le 13/10/2026
# Résilience partagée — version Horizons communs : site approuvé + laboratoire jouable.
# Publie UNE NOUVELLE ADRESSE ; réutilise une clé déjà enregistrée si disponible.
# Sans clé locale : publication anonyme + ouverture du lien de rattachement au compte.
# Ne remplace ni ne supprime aucun site existant. Aucun appel de facturation.
# Site intégral inclus en fin de fichier, contrôlé par SHA-256 avant l'envoi.
# Outils macOS uniquement : ni Python, ni Node, ni Homebrew à installer.
# Documentation de référence : https://here.now/docs — vérifiée le 11/10/2026.
# Aucune clé API n’est demandée. Le fichier d’autorisation temporaire
# est protégé et supprimé à la sortie. Aucun secret n'est intégré au site.
set +x
set +v
set -Eeuo pipefail
umask 077

EXPECTED_SHA='53b30e9694c8756180e26c789b23176a60eb437b8b3c22ef123895d297079b97'
EXPECTED_SIZE='1570663'
STEP='préparation locale'
WORK=''
RUN=''
SITE=''
SLUG=''
API_KEY=''
AUTH=0
CLAIM=''
OWNERSHIP=''
EXPIRY=''

cleanup() {
  unset API_KEY
  if [[ -n "$WORK" && -d "$WORK" ]]; then rm -rf -- "$WORK"; fi
}
fail() {
  printf '\nARRÊT — %s\n' "$1" >&2
  if [[ -n "$SITE" ]]; then
    printf 'Adresse attribuée : %s\n' "$SITE" >&2
    printf 'Cela ne signifie pas que toutes les étapes de publication ont réussi.\n' >&2
  fi
  [[ -z "$RUN" ]] || printf 'Compte rendu local : %s\n' "$RUN" >&2
  exit 1
}
unexpected_error() {
  local code=$?
  trap - ERR
  printf '\nOpération interrompue : %s. Publication complète non confirmée.\n' "$STEP" >&2
  [[ -z "$RUN" ]] || printf 'Compte rendu local : %s\n' "$RUN" >&2
  exit "$code"
}
trap cleanup EXIT
trap unexpected_error ERR
trap 'printf "\nPublication interrompue par l’utilisateur.\n" >&2; exit 130' INT TERM

[[ "$(uname -s)" == 'Darwin' ]] || fail 'Exécute ce lanceur sur ton Mac.'
for tool in curl base64 gzip shasum osascript mktemp awk wc; do
  command -v "$tool" >/dev/null 2>&1 || fail "Outil macOS manquant : $tool."
done
WORK=$(mktemp -d "${TMPDIR:-/tmp/}resilience-herenow.XXXXXX")
STATE="$HOME/Library/Application Support/ResiliencePartagee"
RUN="$STATE/$(date +%Y%m%d-%H%M%S)-$$"
mkdir -p "$RUN"
chmod 700 "$RUN"

cat > "$WORK/json.js" <<'JXA'
ObjC.import('Foundation');
function run(args) {
  var raw = $.NSString.stringWithContentsOfFileEncodingError($(args[0]), $.NSUTF8StringEncoding, null);
  if (!raw) throw new Error('Réponse JSON illisible.');
  var value = JSON.parse(ObjC.unwrap(raw));
  var fields = args[1].split('.');
  for (var i = 0; i < fields.length; i++) {
    if (value === undefined || value === null) return '';
    value = value[fields[i]];
  }
  if (value === null || value === undefined) return '';
  return typeof value === 'object' ? JSON.stringify(value) : String(value);
}
JXA
jget() { osascript -l JavaScript "$WORK/json.js" "$1" "$2"; }

http_check() {
  case "$1" in
    2??) return 0 ;;
    401) fail 'Connexion here.now enregistrée refusée ou expirée. Aucune publication anonyme de remplacement n’a été créée. Vérifie tes accès dans here.now.' ;;
    402) fail 'Limite de compte ou condition tarifaire signalée par here.now. Aucun paiement ni changement d’abonnement effectué.' ;;
    403) fail 'Accès refusé. Vérifie la clé, les droits du compte et les éventuels blocages réseau.' ;;
    409) fail 'Conflit signalé par here.now. Vérifie le tableau de bord avant de relancer.' ;;
    413) fail 'Taille de fichier refusée par here.now. Aucun abonnement ni achat effectué.' ;;
    429) fail 'Limite de requêtes ou de compte atteinte. Consulte le tableau de bord avant de réessayer.' ;;
    *) fail "L’hébergeur a renvoyé HTTP $1 pendant : $STEP. La publication complète n’est pas confirmée." ;;
  esac
}
api_request() {
  local method="$1" url="$2" body="$3" output="$4" retries="${5:-0}"
  # Aucune redirection automatique : le Bearer ne quitte jamais here.now.
  case "$url" in https://here.now/api/*) ;; *) fail 'Adresse API inattendue : arrêt avant envoi de la clé.' ;; esac
  local args=( -q --silent --show-error --proto '=https' --tlsv1.2
    --connect-timeout 20 --max-time 120 --request "$method" --url "$url"
    --config "$WORK/authorization.curl" --output "$output" --write-out '%{http_code}' )
  if [[ -n "$body" ]]; then args+=( --header 'Content-Type: application/json' --data-binary "@$body" ); fi
  if [[ "$retries" != 0 ]]; then args+=( --retry "$retries" --retry-delay 2 ); fi
  if ! HTTP_CODE=$(curl "${args[@]}"); then
    fail "Connexion interrompue pendant : $STEP. Vérifie Internet puis le tableau de bord here.now."
  fi
  http_check "$HTTP_CODE"
}

printf '\nRÉSILIENCE PARTAGÉE — PUBLICATION AUTOMATIQUE\n\n'
printf 'Contenu : dernière version du site, avec la vision structurée, les douze\n'
printf 'étapes, les illustrations conservées, les simulateurs et les documents.\n\n'
printf 'Ce lanceur crée une NOUVELLE adresse publique. Il ne modifie pas les\n'
printf 'anciennes publications. Aucun achat, abonnement ou installation.\n\n'

# Extraction locale uniquement. La charge utile est notre index.html inchangé.
awk '/^__RESILIENCE_SITE_PAYLOAD__$/{found=1; next} found {print}' "$0" \
  | base64 -D | gzip -dc > "$WORK/index.html"
ACTUAL_SHA=$(shasum -a 256 "$WORK/index.html" | awk '{print $1}')
ACTUAL_SIZE=$(wc -c < "$WORK/index.html" | tr -d '[:space:]')
[[ "$ACTUAL_SHA" == "$EXPECTED_SHA" && "$ACTUAL_SIZE" == "$EXPECTED_SIZE" ]] \
  || fail 'Le site intégré est incomplet ou modifié. Télécharge de nouveau le lanceur.'

# Seuls les emplacements documentés de here.now sont lus, sans accès au navigateur.
# Aucun secret n’est demandé, imprimé, ni copié dans le site ou le journal.
API_KEY="${HERENOW_API_KEY:-}"
if [[ -z "$API_KEY" && -f "$HOME/.herenow/credentials" && -r "$HOME/.herenow/credentials" ]]; then
  API_KEY=$(cat "$HOME/.herenow/credentials")
fi
printf 'header = "X-HereNow-Client: chatgpt/macos-automatic-publisher"\n' > "$WORK/authorization.curl"
if [[ -n "$API_KEY" ]]; then
  [[ ${#API_KEY} -ge 20 && ${#API_KEY} -le 1024 ]] || fail 'La connexion here.now enregistrée ne contient pas une clé valide. Aucun envoi effectué.'
  [[ "$API_KEY" =~ ^[A-Za-z0-9._~+/=-]+$ ]] || fail 'Format de la connexion here.now enregistrée inattendu. Aucun envoi effectué.'
  printf 'header = "Authorization: Bearer %s"\n' "$API_KEY" >> "$WORK/authorization.curl"
  AUTH=1
  printf 'Connexion here.now déjà enregistrée : utilisation automatique.\n'
else
  printf 'Publication sans clé API, comme avec le premier lanceur.\n'
  printf 'Une page privée s’ouvrira pour rattacher le site à ton compte.\n'
  printf 'Sans ce rattachement, une publication anonyme expire après 24 heures.\n'
fi
chmod 600 "$WORK/authorization.curl"
unset API_KEY

cat > "$WORK/manifest.json" <<'MANIFEST'
{"files": [{"path": "index.html", "size": 1570663, "contentType": "text/html; charset=utf-8", "hash": "53b30e9694c8756180e26c789b23176a60eb437b8b3c22ef123895d297079b97"}], "ttlSeconds": null, "displayName": "Résilience partagée — Horizons communs", "displayDescription": "Dossier économique, parcours pédagogique et jeu exploratoire DICE–World3 : décisions, crises, comparaisons, hypothèses et sources. Modèle non calibré."}
MANIFEST
STEP='création de la nouvelle publication'
printf '\n[1/5] Création de la nouvelle adresse…\n'
# POST non retenté automatiquement pour éviter les doublons de sites.
api_request POST 'https://here.now/api/v1/publish' "$WORK/manifest.json" "$RUN/creation-privee.json"
# Le lien de rattachement n’est renvoyé qu’une fois : conserver immédiatement la réponse.
cp "$RUN/creation-privee.json" "$WORK/creation.json"
SLUG=$(jget "$WORK/creation.json" slug)
SITE=$(jget "$WORK/creation.json" siteUrl)
[[ "$SLUG" =~ ^[a-z0-9][a-z0-9-]*$ ]] || fail 'Identifiant renvoyé inattendu.'
[[ "$SITE" == "https://$SLUG.here.now/" || "$SITE" == "https://$SLUG.here.now" ]] || fail 'Adresse publique renvoyée inattendue.'
CLAIM=$(jget "$WORK/creation.json" claimUrl)
if [[ "$AUTH" == 1 ]]; then
  [[ "$(jget "$WORK/creation.json" anonymous)" != true && -z "$CLAIM" ]] || fail 'Le rattachement au compte attendu n’est pas confirmé : arrêt avant envoi.'
else
  [[ "$(jget "$WORK/creation.json" anonymous)" == true ]] || fail 'Statut de publication inattendu : arrêt avant envoi.'
  case "$CLAIM" in https://here.now/c/*|https://here.now/claim\?*) ;; *) fail 'Lien de rattachement absent ou inattendu : arrêt avant envoi.' ;; esac
  printf '%s\n' "$CLAIM" > "$RUN/LIEN_PRIVE_POUR_CONSERVER_LE_SITE.txt"
fi
UPLOAD=$(jget "$WORK/creation.json" upload.uploads.0.url)
FINALIZE=$(jget "$WORK/creation.json" upload.finalizeUrl)
VERSION=$(jget "$WORK/creation.json" upload.versionId)
[[ "$VERSION" =~ ^[A-Za-z0-9_-]+$ ]] || fail 'Numéro de version inattendu.'
[[ "$FINALIZE" == "https://here.now/api/v1/publish/$SLUG/finalize" ]] || fail 'Adresse de finalisation inattendue.'
[[ "$(jget "$WORK/creation.json" upload.uploads.length)" == 1 ]] || fail 'Nombre de fichiers à envoyer inattendu.'
[[ "$(jget "$WORK/creation.json" upload.uploads.0.path)" == 'index.html' ]] || fail 'Fichier à envoyer inattendu.'
[[ "$(jget "$WORK/creation.json" upload.uploads.0.method)" == 'PUT' ]] || fail 'Méthode d’envoi inattendue.'
case "$UPLOAD" in https://*.r2.cloudflarestorage.com/*) ;; *) fail 'Le stockage renvoyé ne correspond pas au domaine documenté.' ;; esac
printf 'Adresse attribuée, activation pas encore confirmée :\n%s\n' "$SITE" > "$RUN/ETAT_PUBLICATION.txt"
printf '{"slug":"%s","siteUrl":"%s","versionId":"%s","fileSha256":"%s"}\n' \
  "$SLUG" "$SITE" "$VERSION" "$EXPECTED_SHA" > "$RUN/identifiants-publication.json"

STEP='envoi du site complet'
printf '[2/5] Envoi du site, illustrations et documents intégrés…\n'
# Pas de clé here.now sur la requête au stockage signé.
if ! HTTP_CODE=$(curl -q --silent --show-error --proto '=https' --tlsv1.2 \
  --connect-timeout 20 --max-time 240 --retry 2 --retry-delay 2 \
  --request PUT --url "$UPLOAD" --header 'Content-Type: text/html; charset=utf-8' \
  --data-binary "@$WORK/index.html" --output "$WORK/upload.txt" --write-out '%{http_code}'); then
  fail 'L’envoi a été interrompu. here.now et son stockage cloud doivent être accessibles sur ton réseau.'
fi
http_check "$HTTP_CODE"

STEP='activation de la version'
printf '[3/5] Activation et vérification du statut…\n'
printf '{"versionId":"%s"}\n' "$VERSION" > "$WORK/finalize.json"
# Finalize est idempotent : les nouvelles tentatives visent la même version.
api_request POST "$FINALIZE" "$WORK/finalize.json" "$WORK/confirmation.json" 2
[[ "$(jget "$WORK/confirmation.json" success)" == true ]] || fail 'La mise en ligne n’est pas confirmée par here.now.'
[[ "$(jget "$WORK/confirmation.json" siteUrl)" == "$SITE" ]] || fail 'L’adresse confirmée diffère de l’adresse créée.'
cp "$WORK/confirmation.json" "$RUN/confirmation.json"
[[ "$(jget "$WORK/confirmation.json" publishStatus.state)" == 'live' ]] || fail 'Le statut actif de la publication n’est pas confirmé.'
OWNERSHIP=$(jget "$WORK/confirmation.json" publishStatus.ownership)
PERSISTENCE=$(jget "$WORK/confirmation.json" publishStatus.persistence)
EXPIRY=$(jget "$WORK/confirmation.json" publishStatus.expiresAt)
if [[ "$AUTH" == 1 ]]; then
  [[ "$(jget "$WORK/confirmation.json" publishStatus.requestAuth)" == 'api_key' ]] || fail 'Authentification de la publication non confirmée.'
  [[ "$OWNERSHIP" == 'personal' ]] || fail 'Rattachement au compte personnel non confirmé ; consulte here.now.'
  [[ "$PERSISTENCE" == 'permanent' && -z "$EXPIRY" ]] || fail 'L’absence d’expiration automatique n’est pas confirmée ; consulte les réglages du site.'
  STEP='configuration de l’accès public'
  printf '[4/5] Configuration de l’accès sans compte visiteur…\n'
  printf '{"mode":"anyone_with_link"}\n' > "$WORK/access.json"
  api_request PATCH "https://here.now/api/v1/publish/$SLUG/access" "$WORK/access.json" "$WORK/access-confirmed.json" 2
  [[ "$(jget "$WORK/access-confirmed.json" access.mode)" == 'anyone_with_link' ]] || fail 'L’accès public n’est pas confirmé.'
  cp "$WORK/access-confirmed.json" "$RUN/acces.json"
  printf 'Publication sur le compte personnel, sans expiration automatique annoncée.\n%s\n' "$SITE" > "$RUN/ETAT_PUBLICATION.txt"
else
  # L’accès anonyme est public par défaut. Ne pas utiliser un endpoint réservé aux propriétaires.
  printf '[4/5] Publication anonyme activée ; rattachement au compte à terminer dans le navigateur.\n'
  [[ -n "$EXPIRY" ]] || EXPIRY=$(jget "$WORK/creation.json" expiresAt)
  printf 'Publication anonyme : compte non rattaché par le lanceur.\n%s\nExpiration annoncée : %s\n' "$SITE" "${EXPIRY:-24 heures après publication}" > "$RUN/ETAT_PUBLICATION.txt"
fi
printf '%s\n' "$SITE" > "$RUN/ADRESSE_PUBLIQUE.txt"

STEP='contrôle du contenu sans identification'
printf '[5/5] Vérification de la page publique, sans clé ni session…\n'
VERIFIED=0
for attempt in 1 2 3 4; do
  HTTP_CODE=$(curl -q --silent --show-error --proto '=https' --tlsv1.2 \
    --connect-timeout 15 --max-time 60 --url "$SITE" \
    --output "$WORK/public.html" --write-out '%{http_code}') || HTTP_CODE=000
  if [[ "$HTTP_CODE" == 200 ]]; then
    PUBLIC_SHA=$(shasum -a 256 "$WORK/public.html" | awk '{print $1}')
    if [[ "$PUBLIC_SHA" == "$EXPECTED_SHA" ]]; then
      VERIFIED=1
      break
    fi
    # Certains hébergeurs ajoutent du code : dans ce cas le contrôle exact est
    # non concluant, sans affirmer que l'intégralité de notre fichier est servie.
  fi
  [[ "$attempt" == 4 ]] || sleep 3
done

printf '\nSITE ACTIVÉ PAR HERE.NOW\n\n'
printf 'Adresse publique à partager :\n%s\n\n' "$SITE"
if [[ "$AUTH" == 1 ]]; then
  printf 'Rattachement au compte personnel confirmé par l’hébergeur.\n'
  printf 'Aucune expiration automatique annoncée.\n'
else
  printf 'À TERMINER DANS LE NAVIGATEUR : rattacher ce site à ton compte here.now.\n'
  printf 'Sans cette validation, il reste anonyme et expirera.\n'
  printf 'Expiration annoncée : %s\n' "${EXPIRY:-24 heures après publication}"
  printf '\nLien PRIVÉ de rattachement, à ne pas diffuser :\n%s\n' "$CLAIM"
fi
if [[ "$VERIFIED" == 1 ]]; then
  printf '\nAccès public vérifié : HTTP 200 et contenu intégral identique au fichier.\n'
  printf '\nContrôle public : HTTP 200 et SHA-256 exact.\n' >> "$RUN/ETAT_PUBLICATION.txt"
else
  printf '\nHere.now confirme l’activation, mais le contrôle public n’est pas concluant.\n'
  printf 'Vérifie l’adresse en navigation privée avant de la diffuser.\n'
  printf '\nContrôle du contenu public non concluant.\n' >> "$RUN/ETAT_PUBLICATION.txt"
fi
printf '\nLes anciennes publications ne sont pas modifiées.\n'
printf 'Les adresses sont conservées dans ce dossier PRIVÉ :\n%s\n' "$RUN"
printf 'Ne partage ni son contenu, ni le lien de rattachement.\n'
if command -v open >/dev/null 2>&1; then
  open "$SITE" >/dev/null 2>&1 || true
  [[ -z "$CLAIM" ]] || open "$CLAIM" >/dev/null 2>&1 || true
fi
printf '\nPartage seulement l’adresse publique.\n'
exit 0

