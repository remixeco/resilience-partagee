# Horizons communs — Découverte guidée

## Ouvrir

Ouvrir `index.html` pour consulter le site complet, puis « Jouer ».
Ouvrir `jeu.html` pour commencer directement la partie simple.
Aucune installation ni connexion à un service de calcul n'est nécessaire.
Le mode avancé, son moteur et ses sources sont inclus dans la page.
`laboratoire-avance.html` permet aussi de retrouver directement l'interface détaillée.

## Ce qui a changé

La porte d'entrée n'est plus un tableau de bord à onze leviers. Elle propose six situations,
trois cartes de décision à chaque fois et une explication après chaque choix.
Les cartes annoncent l'avantage recherché et la contrepartie. Le résultat commence par
une phrase ; les nombres précis sont dans « Voir les chiffres et leur sens ».

Les quatre repères sont l'accès aux besoins (« Vie quotidienne »), le budget,
les matières restantes et le réchauffement. Chaque repère ouvre une définition.
Ils ne sont pas agrégés en une note de victoire.

On peut revenir en arrière, rejouer les autres options dans les mêmes conditions,
sauter les questions facultatives, agrandir le texte, exporter/importer la partie
et enregistrer un bilan. Le bouton de lecture vocale utilise les possibilités du navigateur
et du système ; sa disponibilité et ses éventuels services vocaux dépendent de l'appareil.
Aucune IA ni bibliothèque vocale externe n'est appelée par le code du jeu.

## Le moteur n'a pas été changé

Le fichier engine.js est identique à celui du laboratoire précédent, version 1.0.0.
La découverte joue les six premiers tours (30 années fictives) du scénario « energy »,
avec la graine 1. Les deux ruptures d'approvisionnement sont déjà prévues par ce scénario.
La narration d'un quartier n'en fait pas un modèle municipal : les calculs restent globaux
et non calibrés. DICE-2016 et les mécanismes inspirés de World3 conservent leurs limites.
Les cartes traduisent des choix éditoriaux en paramètres, consultables dans l'interface.

## Essais avancés

Le mode avancé commence avec les décisions de la découverte. Les essais qui y sont faits
restent séparés : revenir à la découverte ne remplace pas silencieusement votre parcours.
L'ancien système de sauvegarde avancée reste disponible dans son interface.
Une partie simple et une partie avancée utilisent donc deux formats distincts.

## Confidentialité et sauvegarde

Le stockage local facultatif utilise `horizons.discovery.v1` pour les seuls choix du jeu.
Lorsque le stockage local est indisponible, l'export JSON reste proposé.
Les liens de partage ne deviennent publics qu'après hébergement du site. Ils contiennent
la suite de choix, pas une clé d'hébergement ni des données de compte.
Les journaux techniques éventuels de l'hébergeur restent distincts du code du site.

## Tests

729 parcours guidés complets sont vérifiés : 1 092 transitions, 4 368 contrôles comptables,
rejeu exact, absence de valeurs non finies et refus d'importations incorrectes.
Le contrôle de l'interface a été réalisé avec Chromium sur six largeurs, de 360 à 1 440 pixels,
avec tests des choix, retours, comparaisons, questions facultatives, import/export,
transfert au mode avancé, sensibilité et intégration au site.

Ces contrôles ne constituent ni une étude d'utilisabilité auprès de personnes débutantes,
ni une validation scientifique du modèle. La qualité des voix du système n'a pas été testée.
Les autres navigateurs n'ont pas été testés dans cette session.

## Publication

Le site n'a pas été publié depuis la session de création.
Le fichier `Publier_Resilience_Facile.command` contient le site complet mis à jour.
Il reprend le protocole du lanceur Here.now précédent : nouvelle publication, pas de remplacement
silencieux d'un ancien site. Sa syntaxe et sa charge utile ont été contrôlées ; aucun déploiement
réel n'a été exécuté. Les conditions de l'hébergement restent celles du service.

Sur Mac, placer le lanceur dans Téléchargements, puis :

```bash
bash "$HOME/Downloads/Publier_Resilience_Facile.command"
```

## Modifier et reconstruire

Les sources sont dans `sources/`. Après modification des fichiers de `sources/src/` :

```bash
python3 sources/build.py
node sources/tests/model.test.js
```

Les sorties sont dans `sources/dist/`. Le test d'interface optionnel utilise Playwright et Chromium ;
ils ne sont nécessaires ni pour lire le site ni pour jouer.
Le script de construction recopie aussi les sorties vers `/mnt/data` lorsque ce dossier existe.
Les images précédentes ont été conservées. Aucun fichier de police n'est fourni.
