# Choix pédagogiques et limites

## Intention

Donner accès au raisonnement avant les réglages techniques. Une situation, un choix,
un résultat expliqué, puis des détails facultatifs. Cette conception n'est pas présentée
comme l'application scientifiquement validée d'une méthode unique.

## Six situations

1. Services à renforcer : contribution, réaffectation ou dette.
2. Rupture d'approvisionnement : pas de nouvelle aide, secours limité ou renforcé.
3. Priorité entre équipements, recherche et soutien des revenus.
4. Effort supplémentaire sur les émissions, les matières, ou maintien des réglages.
5. Réserves, diversification ou aide aux revenus avant une nouvelle interruption.
6. Deuxième rupture : observer l'effet de la réponse et des stocks déjà accumulés.

Une période correspond toujours à cinq années du moteur d'origine. Les mots « quartier »,
« école » et « route » sont des analogies. La page le précise ; aucune école, personne,
route, ville ou population locale réelle n'est modélisée.

## Progression de lecture

- Les cartes utilisent des verbes de décision plutôt qu'un nom d'école économique.
- L'avantage recherché est distinct du résultat calculé.
- La contrepartie figure avant la validation, pas uniquement après un mauvais résultat.
- Les chiffres et réglages exacts ne sont pas supprimés ; ils sont accessibles à la demande.
- La petite question teste une distinction, pas la conformité à une opinion politique.
- Les mauvaises réponses reçoivent une explication sans perte de points ni blocage.
- Le bouton Continuer précède les détails facultatifs pour éviter d'obliger à tout lire.
- Le mode avancé n'est pas imposé pour terminer la découverte.

## Comparaisons

Le changement entre l'état précédent et le suivant comprend le temps, les événements
et les politiques héritées. Pour ne pas attribuer tout ce changement au dernier choix,
le retour explicatif compare aussi au même tour sans nouvelle décision et sans secours nouveau.
« Et si j'avais choisi autrement ? » conserve le même état et le même événement pour les trois cartes.
Le bilan final compare à la continuité (réglages BASE, secours 0), pendant le même nombre de tours.
Les essais de sensibilité changent le paramètre dans les deux parcours, et ne remplacent pas la partie.

## Chiffres publics

Le budget est rapporté à 100 unités de production, pas à un budget public de 100.
Le solde montré est annuel au début du tour ; le stock de dette est recalculé sur cinq paiements.
L'accès aux besoins est un indice construit, pas un pourcentage de personnes satisfaites.
Le poids des engagements financiers est rapporté à la production. Une baisse de ce poids
ne doit pas être décrite comme une baisse certaine du montant de la dette.
Les matières sont un stock non renouvelable agrégé fictif ; elles ne mesurent pas toute la nature.

## Limites de cette simplification

Six situations et trois options par étape ne couvrent pas toutes les politiques possibles.
Le choix des situations, des options et des valeurs associées est éditorial et influence
ce que le joueur explore, même si les équations sont inchangées et qu'aucun bonus idéologique
n'est ajouté. Les comparaisons ne démontrent pas la supériorité d'une doctrine dans la réalité.

La version devrait encore être observée avec des personnes débutantes : peuvent-elles
expliquer ce qu'elles ont choisi, identifier une contrepartie, puis distinguer un résultat
de jeu d'une prévision réelle ? Aucun résultat de ce type n'est revendiqué ici.
